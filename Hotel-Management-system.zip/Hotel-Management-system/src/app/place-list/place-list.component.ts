import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Place } from '../place';
import { PlaceService } from '../place.service';

@Component({
  selector: 'app-place-list',
  templateUrl: './place-list.component.html',
  styleUrls: ['./place-list.component.css']
})
export class PlaceListComponent implements OnInit {
  places:Place[];

  constructor(private placeService:PlaceService,private route:Router) { }

  ngOnInit(): void {
    this.getPlaceList();
  }

 
  
 private getPlaceList()
{
  this.placeService.getPlaceListService().subscribe(data => {
    this.places = data;
  });}

 updatePlace(placeId:number)
  {
    this.route.navigate(['/updateplace',placeId]);
  }
deletePlace(placeId:number)
{
 
this.placeService.deletePlaceService(placeId).subscribe(
  data=>{console.log("succuss"),
  this.getPlaceList();},
  error=>console.log("error")
)
}
addHotel(placeId:number)
{
  this.route.navigate(['/createhotel',placeId])
}
viewHotel(placeId:number)
{
  this.route.navigate(['/hotellist',placeId])
}

logOut()
{
  this.route.navigate(['/welcomepage'])
}
back()
{
  this.route.navigate(['/adminhome'])
}
}
