import { Payement } from './payement';

describe('Payement', () => {
  it('should create an instance', () => {
    expect(new Payement()).toBeTruthy();
  });
});
