import { Facilities } from './facilities';

describe('Facilities', () => {
  it('should create an instance', () => {
    expect(new Facilities()).toBeTruthy();
  });
});
