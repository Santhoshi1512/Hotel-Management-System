import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Payement } from '../payement';
import { PayementService } from '../payement.service';

@Component({
  selector: 'app-receipt',
  templateUrl: './receipt.component.html',
  styleUrls: ['./receipt.component.css']
})
export class ReceiptComponent implements OnInit {
payementId:number
customerId:number
payement=new Payement();
  constructor(private activatedRoute:ActivatedRoute,private route:Router,private payementService:PayementService) { }

  ngOnInit(): void {
this.payementId=this.activatedRoute.snapshot.params["payementId"]
this.customerId=this.activatedRoute.snapshot.params["customerId"]

  this.getPayementDetails();
  }
getPayementDetails()
{
  this.payementService.getPayementDetailsService(this.payementId).subscribe(
    data=>{console.log(data),
    this.payement=data},
    error=>console.log(error)
  )
}
home()
{
  this.route.navigate(['/customerhomeplace',this.customerId])
}
logOut()
{
  this.route.navigate(['/welcomepage'])
}
}
