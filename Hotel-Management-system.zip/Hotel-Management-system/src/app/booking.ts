export class Booking {
    bookingId:number
   bookedDate:String
    checkIn:Date
    checkOut:Date
    hotelName:String
    hotelPlace:String
    roomType:String
    roomNumber:String;
    roomPrice:number
}
