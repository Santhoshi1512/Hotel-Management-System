import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AvailabilityComponent } from './availability/availability.component';
import { BookingListComponent } from './booking-list/booking-list.component';
import { ContactUsComponent } from './contact-us/contact-us.component';

import { CreateFacilitiesComponent } from './create-facilities/create-facilities.component';
import { CreateHotelComponent } from './create-hotel/create-hotel.component';
import { CreateRoomComponent } from './create-room/create-room.component';
import { CustomerHomeComponent } from './customer-home/customer-home.component';
import { CustomerListComponent } from './customer-list/customer-list.component';

import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { CustomerProfileComponent } from './customer-profile/customer-profile.component';

import { CustomerRegisterComponent } from './customer-register/customer-register.component';
import { FacilitiesListComponent } from './facilities-list/facilities-list.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { HotelListComponent } from './hotel-list/hotel-list.component';
import { PayementListComponent } from './payement-list/payement-list.component';
import { PayementComponent } from './payement/payement.component';
import { ReceiptComponent } from './receipt/receipt.component';
import { RoomListComponent } from './room-list/room-list.component';
import { UpdateFacilitiesComponent } from './update-facilities/update-facilities.component';
import { UpdateHotelComponent } from './update-hotel/update-hotel.component';
import { UpdateRoomComponent } from './update-room/update-room.component';
import { ViewBookingListComponent } from './view-booking-list/view-booking-list.component';
import { ViewFacilityListComponent } from './view-facility-list/view-facility-list.component';
import { ViewRoomListComponent } from './view-room-list/view-room-list.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { CreatePlaceComponent } from './create-place/create-place.component';
import { PlaceListComponent } from './place-list/place-list.component';
import { UpdatePlaceComponent } from './update-place/update-place.component';
import { CustomerHomePlaceComponent } from './customer-home-place/customer-home-place.component';


const routes: Routes = [{ path: '', component:WelcomeComponent},
{ path: 'welcomepage', component:WelcomeComponent},
{ path: 'customerlogin', component: CustomerLoginComponent},
{ path: 'customerregister', component: CustomerRegisterComponent},
{ path: 'adminlogin', component: AdminLoginComponent},
{ path: 'welcome', component: WelcomeComponent},
{ path: 'createhotel/:placeId', component: CreateHotelComponent},
{ path: 'adminhome', component: AdminHomeComponent},
{ path: 'hotellist/:placeId', component: HotelListComponent},
{ path: 'roomlist', component: RoomListComponent},
{ path: 'createroom', component: CreateRoomComponent},
{ path: 'updateroom/:roomId/:id/:placeId', component: UpdateRoomComponent},
{ path: 'createfacility/:id/:placeId', component: CreateFacilitiesComponent},
{ path: 'facilitieslist/:id/:placeId', component: FacilitiesListComponent},
{ path: 'updatefacility/:facilityId/:id/:placeId', component: UpdateFacilitiesComponent},
{ path: 'updatehotel/:id/:placeId', component: UpdateHotelComponent},
{ path: 'createroom/:id/:placeId', component: CreateRoomComponent},
{ path: 'roomlist/:id/:placeId', component: RoomListComponent},
{ path: 'customerhome/:placeId/:customerId', component: CustomerHomeComponent},
{ path: 'bookinglist', component: BookingListComponent},
{ path: 'viewbookinglist/:customerId', component: ViewBookingListComponent},
{ path: 'customerhomeplace/:customerId', component: CustomerHomePlaceComponent},

{ path: 'viewroomlist/:id/:customerId/:placeId', component: ViewRoomListComponent},
{ path: 'viewfaclist/:id/:customerId/:placeId', component: ViewFacilityListComponent},
{ path: 'payementform/:roomId/:customerId/:id/:checkIn/:checkOut', component: PayementComponent},
{ path: 'profile/:customerId', component: CustomerProfileComponent},
{ path: 'payementlist', component: PayementListComponent},
{ path: 'customerlist', component: CustomerListComponent},
{ path: 'payementreciept/:customerId/:payementId', component: ReceiptComponent},
{ path: 'availability/:roomId', component: AvailabilityComponent},
{ path: 'aboutus', component: AboutUsComponent},
{ path: 'forgotpassword', component: ForgotPasswordComponent},
{ path: 'updateplace/:placeId', component: UpdatePlaceComponent},

{ path: 'contact', component: ContactUsComponent},
{ path: 'createplace', component:CreatePlaceComponent},
{ path: 'placelist', component:PlaceListComponent},









];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
