import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Place } from './place';

@Injectable({
  providedIn: 'root'
})
export class PlaceService {

  constructor(private http:HttpClient) { }
  private url="http://localhost:8080/api/places";
  public createPlaceService(place:Place):Observable<Object>
  {
return this.http.post<any>("http://localhost:8080/api/places",place)
  }
  public getPlaceListService():Observable<Place[]>
  {
    return this.http.get<Place[]>("http://localhost:8080/api/places")
  }
  public deletePlaceService(placeId:number):Observable<any>
{
  return this.http.delete(`${this.url}/${placeId}`);
}
public getPlaceByIdService(placeId:number):Observable<Place>
{
  
  return this.http.get<Place>(`${this.url}/${placeId}`);
}
public updatePlaceService(placeId:number,place:Place):Observable<any>
{
  return this.http.put(`${this.url}/${placeId}`,place);
}
}
