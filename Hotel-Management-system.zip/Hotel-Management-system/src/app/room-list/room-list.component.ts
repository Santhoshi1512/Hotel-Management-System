import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Room } from '../room';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-room-list',
  templateUrl: './room-list.component.html',
  styleUrls: ['./room-list.component.css']
})
export class RoomListComponent implements OnInit {
rooms:Room[]
message=""
id:number;
placeId:number
  constructor(private roomService:RoomService,private router:Router,private activatedroute: ActivatedRoute) { }

  ngOnInit(): void {
    this.getRoomList();
    this.placeId=this.activatedroute.snapshot.params["placeId"];

  }
  private getRoomList()
  {
    this.id=this.activatedroute.snapshot.params["id"];
    this.roomService.getRoomListService(this.id).subscribe(data => {
      this.rooms = data;
    });
}

  updateRoom(roomId: number)
  {
this.router.navigate(['/updateroom',roomId,this.id,this.placeId])
  }
  
  deleteRoom(roomId:number)
  {
    this.roomService.deleteRoomService(roomId).subscribe(
      data=>{console.log("deleted Successfully"),
    
      this.getRoomList();},
      error=>{console.log("delete failed"),
    this.message="unable to delete. please try again!"}
    )
  }
  logOut()
{
  this.router.navigate(['/welcomepage'])
}
back()
{
  this.router.navigate(['/hotellist',this.placeId])
}
}
