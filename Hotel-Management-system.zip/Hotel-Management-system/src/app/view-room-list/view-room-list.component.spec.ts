import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewRoomListComponent } from './view-room-list.component';

describe('ViewRoomListComponent', () => {
  let component: ViewRoomListComponent;
  let fixture: ComponentFixture<ViewRoomListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewRoomListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewRoomListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
