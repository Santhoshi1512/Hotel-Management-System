import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Booking } from '../booking';
import { BookingService } from '../booking.service';
import { Customer } from '../customer';
import { Payement } from '../payement';
import { PayementService } from '../payement.service';
import { Room } from '../room';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-view-room-list',
  templateUrl: './view-room-list.component.html',
  styleUrls: ['./view-room-list.component.css']
})
export class ViewRoomListComponent implements OnInit {
  rooms:Room[]
  customer:Customer
  id:number;
  placeId:number
  customerId:number
  nightSelected:number;
  totalPrice:number
  payement=new Payement();
status:boolean;
booking=new Booking();

  
  constructor(private payementService:PayementService,private roomService:RoomService,private router:Router,private activatedroute: ActivatedRoute,private bookingService: BookingService) { }
  date=new Date();
  currentYear=this.date.getUTCFullYear();
  currentMonth=this.date.getUTCMonth()+1;
  currentday=this.date.getUTCDate();
  FinalMonth:any;
  FinalDay:any;
 todayDate:String
  ngOnInit(): void {
    if(this.currentMonth<10)
    {
      this.FinalMonth="0"+this.currentMonth;
    
    }else{
      this.FinalMonth=this.currentMonth;
    }
   
    if(this.currentday<10)
    {
      this.FinalDay="0"+this.currentday;
    
    }else{
      this.FinalDay=this.currentday;
    }
this.todayDate=this.FinalMonth+"-"+this.FinalDay+"-"+this.currentYear;
console.log("System Date"+this.todayDate)

this.customerId=this.activatedroute.snapshot.params["customerId"]
this.placeId=this.activatedroute.snapshot.params["placeId"]

    this.getRoomList();
  }
   getRoomList()
  {
    this.id=this.activatedroute.snapshot.params["id"];
    this.roomService.getRoomListService(this.id).subscribe(data => {
   
      this.rooms = data;

   console.log(this.rooms)
 
     
    });
}
bookRoom(checkIn:Date,checkOut:Date,roomId:number)
{
  if(this.payement.checkIn==null||this.payement.checkOut==null)
{
alert("Please Choose Check In and Check Out....... ")
}else{
    this.bookingService.checkAvailabilityService(checkIn,checkOut,roomId).subscribe(
    data=>{console.log(data),
    this.status=data
    if(this.status==true)
  
    {
      alert("Sorry! Room is Booked For This Date")
    }
    else if(this.status==false)
    {
      this.router.navigate(['/payementform',roomId,this.customerId,this.id,this.payement.checkIn,this.payement.checkOut])

    }
   
  }
  )    
}
}



nights = [1, 2, 3, 4, 5];
logOut()
{
  this.router.navigate(['/welcomepage'])
}
back()
{
  this.router.navigate(['/customerhome',this.placeId,this.customerId])
}
home()
{
  this.router.navigate(['/customerhomeplace',this.customerId])
}
customerProfile()
{
  this.router.navigate(['profile',this.customerId])
}

checkAvaialabilty(checkIn:Date,checkOut:Date,roomId:number)
{
  this.router.navigate(['/availability',roomId])


}

bookingDetails()
{
  this.router.navigate(['/viewbookinglist',this.customerId])
}
contactUs()
    {
      this.router.navigate(['/contact'])
    }
}
