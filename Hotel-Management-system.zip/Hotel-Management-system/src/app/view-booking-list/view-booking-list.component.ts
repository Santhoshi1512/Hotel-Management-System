import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Booking } from '../booking';
import { BookingService } from '../booking.service';

@Component({
  selector: 'app-view-booking-list',
  templateUrl: './view-booking-list.component.html',
  styleUrls: ['./view-booking-list.component.css']
})
export class ViewBookingListComponent implements OnInit {
  bookings:Booking[]
  customerId:number
  constructor(private bookingService:BookingService,private activatedRoute:ActivatedRoute,private route:Router) { }
  date=new Date();
  currentYear=this.date.getUTCFullYear();
  currentMonth=this.date.getUTCMonth()+1;
  currentday=this.date.getUTCDate();
  FinalMonth:any;
  FinalDay:any;
 todayDate:String
 todayDate1:Date
  ngOnInit(): void {
    this.customerId=this.activatedRoute.snapshot.params["customerId"]
  this.getAllBookings()
  if(this.currentMonth<10)
  {
    this.FinalMonth="0"+this.currentMonth;
  
  }else{
    this.FinalMonth=this.currentMonth;
  }
 
  if(this.currentday<10)
  {
    this.FinalDay="0"+this.currentday;
  
  }else{
    this.FinalDay=this.currentday;
  }
this.todayDate=this.FinalMonth+"/"+this.FinalDay+"/"+this.currentYear;
console.log("System Date"+this.todayDate)


  }
  getAllBookings()
  {

  
  this.bookingService.getAllBookingsByCustomerIdService(this.customerId).subscribe(
    data=>{console.log(data),
    this.bookings=data},
    error=>console.log(error)
  )
    }
  cancelBooking(bookingId:number)
  {
    this.bookingService.deleteBookingService(bookingId).subscribe(
      data=>{console.log("Deleted Succesfully"),
      alert("Booking Cancelled....Please Contact Us To Get Back Your Money..")
      this.getAllBookings();},
      error=>console.log("error")
    )
  }

  logOut()
  {
    this.route.navigate(['/welcomepage'])
  }
  
  home()
  {
    this.route.navigate(['/customerhome',this.customerId])
  }
  contactUs()
    {
      this.route.navigate(['/contact'])
    }
}
