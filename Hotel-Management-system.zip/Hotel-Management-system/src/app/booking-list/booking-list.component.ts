import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Booking } from '../booking';
import { BookingService } from '../booking.service';

@Component({
  selector: 'app-booking-list',
  templateUrl: './booking-list.component.html',
  styleUrls: ['./booking-list.component.css']
})
export class BookingListComponent implements OnInit {
bookings:Booking[]
  constructor(private bookingService:BookingService,private route:Router) { }

  ngOnInit(): void {
  this.getAllBookings()

  }
  getAllBookings()
  {

  
  this.bookingService.getAllBookingsService().subscribe(
    data=>{console.log(data),
    this.bookings=data},
    error=>console.log(error)
  )
    }
  deleteBooking(bookingId:number)
  {
    this.bookingService.deleteBookingService(bookingId).subscribe(
      data=>{console.log("Deleted Succesfully"),
      this.getAllBookings();},
      error=>console.log("error")
    )
  }
  logOut()
  {
    this.route.navigate(['/welcomepage'])
  }
}
