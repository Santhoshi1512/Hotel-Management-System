import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Facilities } from '../facilities';
import { FacilitiesService } from '../facilities.service';

@Component({
  selector: 'app-update-facilities',
  templateUrl: './update-facilities.component.html',
  styleUrls: ['./update-facilities.component.css']
})
export class UpdateFacilitiesComponent implements OnInit {
facility:Facilities =new Facilities;
facilityId:number;
message=""
id:number
placeId:number
  constructor(private activatedRoute:ActivatedRoute,private facilitiesService:FacilitiesService,private route:Router) { }

  ngOnInit(): void {
    this.placeId=this.activatedRoute.snapshot.params["placeId"];

    this.facilityId=this.activatedRoute.snapshot.params["facilityId"];
        this.id=this.activatedRoute.snapshot.params["id"];
    this.facilitiesService.getFacilitiesByIdService(this.facilityId).subscribe(
      data=>{this.facility=data,
      console.log(data)},

      error=>console.log(error)
    );
  }
  updateFacility()
  {
this.facilitiesService.updateFacilityervice(this.facilityId,this.facility).subscribe(
  data=>{console.log("Update Succesful"),
  alert("updated successfully")
  this.route.navigate(['/facilitieslist',this.id,this.placeId])},
  error=>{console.log("update failed"),
this.message="update failed!. please try again"}
)
  }
  logOut()
{
  this.route.navigate(['/welcomepage'])
}
  }


