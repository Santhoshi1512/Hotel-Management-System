export class Place {
    placeId:number;
    placeName:String
    image:String
}
