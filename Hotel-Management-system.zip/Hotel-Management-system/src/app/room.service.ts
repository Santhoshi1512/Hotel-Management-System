import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Room } from './room';

@Injectable({
  providedIn: 'root'
})
export class RoomService {

  constructor(private http:HttpClient) { }
  public createRoomService(room:Room,id:number):Observable<Object>
  {
return this.http.post<any>(`${this.url}/${id}`,room)
  }

public getRoomListService(id:number):Observable<any>
{
  return this.http.get<any>(`${this.url}/${id}`);
}

private url="http://localhost:8080/api/rooms";
private url1="http://localhost:8080/api/rooms/rooms";

public getRoomByIdService(roomId:number):Observable<Room>
{
  
  return this.http.get<Room>(`${this.url1}/${roomId}`);
}
public updateRoomService(roomId:number,room:Room):Observable<any>
{
  return this.http.put(`${this.url}/${roomId}`,room);
}
public deleteRoomService(roomId:number):Observable<any>
{
  return this.http.delete(`${this.url}/${roomId}`);
}

}
