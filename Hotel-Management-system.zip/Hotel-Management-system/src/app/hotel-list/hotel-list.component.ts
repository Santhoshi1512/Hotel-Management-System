import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Hotel } from '../hotel';
import { HotelService } from '../hotel.service';


@Component({
  selector: 'app-hotel-list',
  templateUrl: './hotel-list.component.html',
  styleUrls: ['./hotel-list.component.css']
})
export class HotelListComponent implements OnInit {
hotels:Hotel[];
placeId:number
  constructor(private hotelService:HotelService,private route:Router,private activatedRout:ActivatedRoute) { }

  ngOnInit(): void {
    this.getHotelList();
  }

 
  
 private getHotelList()
{
  this.placeId=this.activatedRout.snapshot.params["placeId"];
    this.hotelService.getHotelListService(this.placeId).subscribe(data => {
      this.hotels = data;
    });}

 updateHotel(id:number)
  {
    this.route.navigate(['/updatehotel',id,this.placeId]);
  }
deleteHotel(id:number)
{
 
this.hotelService.deleteHotelService(id).subscribe(
  data=>{console.log("succuss"),
  this.getHotelList();},
  error=>console.log("error")
)
}
addRoom(id:number)
{
  this.route.navigate(['/createroom',id,this.placeId])
}
viewRoom(id:number)
{
  this.route.navigate(['/roomlist',id,this.placeId])
}
addFacilitiy(id:number)
{
  this.route.navigate(['/createfacility',id,this.placeId])
}
viewFacilities(id:number)
{
  this.route.navigate(['/facilitieslist',id,this.placeId])

}
logOut()
{
  this.route.navigate(['/welcomepage'])
}
back()
{
  this.route.navigate(['/placelist'])
}
}
  


