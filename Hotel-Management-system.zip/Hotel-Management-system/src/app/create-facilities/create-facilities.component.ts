import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Facilities } from '../facilities';
import { FacilitiesService } from '../facilities.service';

@Component({
  selector: 'app-create-facilities',
  templateUrl: './create-facilities.component.html',
  styleUrls: ['./create-facilities.component.css']
})
export class CreateFacilitiesComponent implements OnInit {
facilities=new Facilities();
id:number;
message=""
placeId:number
  constructor(private facilitiesService:FacilitiesService,private rout:Router,private activatedroute:ActivatedRoute) { }

  ngOnInit(): void {
    this.placeId=this.activatedroute.snapshot.params["placeId"];

  }
  saveFacility()
  {
    this.id=this.activatedroute.snapshot.params["id"];
    this.facilitiesService.createFacilitiesService(this.facilities,this.id).subscribe(
      data=>{console.log("Added Succesfully"),
      alert("facility added successfully")
      this.goToFacilityList();},
      error=>{console.log("Adding failed"),
      this.message="Failed!.Try Again"}

    )
  }
  goToFacilityList()
  {
this.rout.navigate(['/facilitieslist',this.id,this.placeId])
  }
onSubmit()
{
  this.saveFacility();
}
logOut()
{
  this.rout.navigate(['/welcomepage'])
}
}
