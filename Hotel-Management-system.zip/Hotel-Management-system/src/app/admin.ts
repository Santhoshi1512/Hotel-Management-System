export class Admin {
    adminId:number;
  firstName:String;
  lastName:String;;
  adminEmailId:String;
  adminPassword:String
    
    
}
