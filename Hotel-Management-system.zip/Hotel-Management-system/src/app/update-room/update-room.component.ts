import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { Customer } from '../customer';
import { Room } from '../room';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-update-room',
  templateUrl: './update-room.component.html',
  styleUrls: ['./update-room.component.css']
})
export class UpdateRoomComponent implements OnInit {
  roomId:number;
  id:number
room:Room=new Room();
message=""
placeId:number
  constructor(private roomService:RoomService,private activatedRoute:ActivatedRoute, private route:Router) { }

  ngOnInit(): void {
    this.placeId=this.activatedRoute.snapshot.params["placeId"];

  this.roomId=this.activatedRoute.snapshot.params["roomId"];
    this.id=this.activatedRoute.snapshot.params["id"];
    this.roomService.getRoomByIdService(this.roomId).subscribe(
      data=>this.room=data,
      error=>console.log(error)
    );
  }
  updateRoom()
  {
    console.log(this.room)
    this.roomService.updateRoomService(this.roomId,this.room).subscribe(
      data=>{console.log("updated succesfully"),
      alert("updated succesfully")
      this.route.navigate(['/roomlist',this.id,this.placeId])},
      error=>{console.log("update failed"),
      this.message="update  faled. please try again"}
    )
  }
statuses=["true","false"]
logOut()
{
  this.route.navigate(['/welcomepage'])
}
}
