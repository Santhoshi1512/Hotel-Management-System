export class Room {
    roomId:number;
    image:String;
    roomNumber:String;
    roomType:String;
    roomPrice:number;
    roomDetails:String;
    customer:Object;
    nightSelected:number;
    status:boolean

}
