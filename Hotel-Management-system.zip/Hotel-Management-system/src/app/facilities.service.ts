import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Facilities } from './facilities';

@Injectable({
  providedIn: 'root'
})
export class FacilitiesService {

  constructor(private http:HttpClient) { }
  private url="http://localhost:8080/api/facilities";
  private url1="http://localhost:8080/api/facilities/facilities";

public createFacilitiesService(facilities:Facilities,id:number):Observable<any>
{
  return this.http.post<any>(`${this.url}/${id}`,facilities);
}
public getFacilitiesListService(id:number):Observable<Facilities[]>
{
  return this.http.get<Facilities[]>(`${this.url}/${id}`);
}

public getFacilitiesByIdService(facilityId:number):Observable<Facilities>
{
  
  return this.http.get<Facilities>(`${this.url1}/${facilityId}`);
}
public updateFacilityervice(id:number,facility:Facilities):Observable<any>
{
  return this.http.put(`${this.url}/${id}`,facility);
}
public deleteFacilityService(facilityId:number):Observable<any>
{
  return this.http.delete(`${this.url}/${facilityId}`);
}
}