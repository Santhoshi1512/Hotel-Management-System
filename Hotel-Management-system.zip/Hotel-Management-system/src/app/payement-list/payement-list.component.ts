import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Payement } from '../payement';
import { PayementService } from '../payement.service';

@Component({
  selector: 'app-payement-list',
  templateUrl: './payement-list.component.html',
  styleUrls: ['./payement-list.component.css']
})
export class PayementListComponent implements OnInit {
payements:Payement[];
  constructor(private payementService:PayementService,private route:Router) { }

  ngOnInit(): void {
    this.payementService.getAllPayementsService().subscribe(
      data=>this.payements=data,
      error=>console.log(error)
    )
  }
  logOut()
  {
    this.route.navigate(['/welcomepage'])
  }
}
