export class Facilities {
    facilityId:number;
    image:String;
    facilityName:String;
    availableTime:String
}
