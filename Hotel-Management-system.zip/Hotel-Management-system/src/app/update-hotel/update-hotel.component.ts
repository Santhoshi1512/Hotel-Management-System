import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Hotel } from '../hotel';
import { HotelService } from '../hotel.service';

@Component({
  selector: 'app-update-hotel',
  templateUrl: './update-hotel.component.html',
  styleUrls: ['./update-hotel.component.css']
})
export class UpdateHotelComponent implements OnInit {
id:number;
hotel=new Hotel();
message=""
placeId:number
  constructor(private activatedroute:ActivatedRoute,private hotelService:HotelService,private route:Router)
   { }

  ngOnInit(): void {
    this.placeId=this.activatedroute.snapshot.params["placeId"];

this.id=this.activatedroute.snapshot.params["id"];
this.hotelService.getHotelByIdService(this.id).subscribe(
  data=>{this.hotel=data,
  console.log(data)},
 
  error=>console.log(error),
   
)
  }
  updateFacility()
  {
    this.hotelService.updateHotelService(this.id,this.hotel).subscribe(
      data=>{console.log(data),
        alert("updated successfully")
      this.route.navigate(['/hotellist',this.placeId])},
      error=>console.log("update failed")
    )
  }
  logOut()
  {
    this.route.navigate(['/welcomepage'])
  }
}
