import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from './customer';
import { Payement } from './payement';
import { Room } from './room';

@Injectable({
  providedIn: 'root'
})
export class PayementService {

  constructor(private http:HttpClient) { }
  private url1="http://localhost:8080/api/rooms/rooms"

  public getRoomDetailsService(roomId:number,):Observable<Room>
  {
    return this.http.get<Room>(`${this.url1}/${roomId}`)
  }
  private url2="http://localhost:8080/api/customers"
  public getCustomerDetailsService(customerId:number):Observable<Customer>
  {
    return this.http.get<Customer>(`${this.url2}/${customerId}`)
  }
  private url3="http://localhost:8080/api/rooms"

  public bookRoomService(roomId:number,customerId:number,room:Room):Observable<any>
{
return this.http.put(`${this.url3}/${roomId}/${customerId}`,room);
}
private url4="http://localhost:8080/api/payements"
 public addToPayementService(roomId:number,customerId:number,id:number,payement:Payement):Observable<any>
 {
   return this.http.post<any>(`${this.url4}/${roomId}/${customerId}/${id}`,payement)
 }
 public getAllPayementsService():Observable<Payement[]>
 {
   return this.http.get<Payement[]>("http://localhost:8080/api/payements")
 }
 public getPayementDetailsService(payementId:number):Observable<Payement>
 {
   return this.http.get<Payement>(`${this.url4}/${payementId}`)
 }
 public checkAvailabilityService(checkIn:Date,checkOut:Date,roomId:number):Observable<any>
 {
   return this.http.get<any>(`${this.url4}/${checkIn}/${checkOut}/${roomId}`);
 }
}
