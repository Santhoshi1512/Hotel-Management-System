import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Booking } from '../booking';
import { BookingService } from '../booking.service';

@Component({
  selector: 'app-availability',
  templateUrl: './availability.component.html',
  styleUrls: ['./availability.component.css']
})
export class AvailabilityComponent implements OnInit {
bookings:Booking[]
roomId:number
  constructor(private bookingService:BookingService,private activatedRoute:ActivatedRoute,private route:Router) { }

  ngOnInit(): void {
this.roomId=this.activatedRoute.snapshot.params["roomId"]
    this.bookingService.getAllBookingsByRoomIdService(this.roomId).subscribe(
      data=>
      this.bookings=data,
    
    )
  }
  logOut()
{
  this.route.navigate(['/welcomepage'])
}
}
