import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Facilities } from '../facilities';
import { FacilitiesService } from '../facilities.service';

@Component({
  selector: 'app-view-facility-list',
  templateUrl: './view-facility-list.component.html',
  styleUrls: ['./view-facility-list.component.css']
})
export class ViewFacilityListComponent implements OnInit {
  facilities:Facilities[];
  id:number;
  customerId:number
  placeId:number
  constructor(private facilityService:FacilitiesService,private router :Router,private activatedroute:ActivatedRoute) { }

  ngOnInit(): void {
    this.getfacilitiesList();
    this.customerId=this.activatedroute.snapshot.params["customerId"];
    this.placeId=this.activatedroute.snapshot.params["placeId"];


  }
  getfacilitiesList(){
    this.id=this.activatedroute.snapshot.params["id"];
      this.facilityService.getFacilitiesListService(this.id).subscribe(
        data=>{this.facilities=data,
        console.log(data)}
    )
        
       


}
logOut()
{
  this.router.navigate(['/welcomepage'])
}
back()
{
  this.router.navigate(['/customerhome',this.placeId,this.customerId,])
}
home()
{
  this.router.navigate(['/customerhomeplace',this.customerId])
}
customerProfile()
{
  this.router.navigate(['profile',this.customerId])
}

checkAvaialabilty(checkIn:Date,checkOut:Date,roomId:number)
{
  this.router.navigate(['/availability',roomId])


}

bookingDetails()
{
  this.router.navigate(['/viewbookinglist',this.customerId])
}
contactUs()
    {
      this.router.navigate(['/contact'])
    }
}
