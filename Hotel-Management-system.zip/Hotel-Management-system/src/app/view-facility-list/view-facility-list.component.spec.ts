import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewFacilityListComponent } from './view-facility-list.component';

describe('ViewFacilityListComponent', () => {
  let component: ViewFacilityListComponent;
  let fixture: ComponentFixture<ViewFacilityListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewFacilityListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewFacilityListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
