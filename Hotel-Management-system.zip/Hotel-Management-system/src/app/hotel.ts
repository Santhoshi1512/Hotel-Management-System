export class Hotel {
id:number;
image:String;
   hotelName:String ;
   hotelPlace:String;
   hotelDetails:String
}
