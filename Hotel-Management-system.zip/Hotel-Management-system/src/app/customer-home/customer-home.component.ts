import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Hotel } from '../hotel';
import { HotelService } from '../hotel.service';

@Component({
  selector: 'app-customer-home',
  templateUrl: './customer-home.component.html',
  styleUrls: ['./customer-home.component.css']
})
export class CustomerHomeComponent implements OnInit {
  hotels:Hotel[];
  customerId:number
  placeId:number
  constructor(private hotelService:HotelService,private route:Router,private activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {
this.customerId=this.activatedRoute.snapshot.params["customerId"]
this.placeId=this.activatedRoute.snapshot.params["placeId"]

    this.getHotelList();
  }
  private getHotelList()
  {
    this.hotelService.getHotelListService(this.placeId).subscribe(data => {
      this.hotels = data;
    });}
    getRoomList(id:number)
    {
      this.route.navigate(['/viewroomlist',id,this.customerId,this.placeId])
    }
    getFacilityList(id:number)
    {
      this.route.navigate(['/viewfaclist',id,this.customerId,this.placeId])
    }
    customerProfile()
    {
      this.route.navigate(['/profile',this.customerId])
    }
    logOut()
    {
      this.route.navigate(['/welcomepage'])
    }
    back()
    {
      this.route.navigate(['/customerhomeplace',this.customerId])
    }
    bookingDetails ()
    {
      this.route.navigate(['/viewbookinglist',this.customerId])
    }
    contactUs()
    {
      this.route.navigate(['/contact'])
    }
}
