import { Injectable } from '@angular/core';
import {HttpClient} from'@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService{

  constructor(private _http:HttpClient) { }
  public customerRegisterService(customer:Customer):Observable<any>
  {
    return this._http.post<any>("http://localhost:8080/api/customers/register",customer)
  }
  public customerLoginService(customer:Customer):Observable<any>
  {
    return this._http.post<any>("http://localhost:8080/api/customers/login",customer)
  }
  private url="http://localhost:8080/api/customers"
  public getCustomerById(customerId:number):Observable<Customer>
  {
    return this._http.get<Customer>(`${this.url}/${customerId}`);
  }
public saveProfileService(customerId:number,customer:Customer):Observable<any>
{
  return this._http.put<any>(`${this.url}/${customerId}`,customer)
}
public getAllCustomersService():Observable<Customer[]>
{
  return this._http.get<Customer[]>("http://localhost:8080/api/customers");
}

public getCustomerByEmail(customer:Customer):Observable<any>
{
  return this._http.post<any>("http://localhost:8080/api/customers/forgotpass",customer)
}
}
