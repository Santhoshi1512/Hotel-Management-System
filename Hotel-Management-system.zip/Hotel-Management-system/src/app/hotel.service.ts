import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Hotel } from './hotel';

@Injectable({
  providedIn: 'root'
})
export class HotelService {

  constructor(private http:HttpClient) { }
  private url="http://localhost:8080/api/hotels";
  private url1="http://localhost:8080/api/hotels/hotels";

  public createHotelService(hotel:Hotel,placeId:number):Observable<Object>
  {
return this.http.post<any>(`${this.url}/${placeId}`,hotel)
  }
  public getHotelListService(placeId:number):Observable<Hotel[]>
  {
    return this.http.get<Hotel[]>(`${this.url}/${placeId}`)
  }
  
public getHotelByIdService(id:number):Observable<Hotel>
{
  
  return this.http.get<Hotel>(`${this.url1}/${id}`);
}
public updateHotelService(id:number,hotel:Hotel):Observable<any>
{
  return this.http.put(`${this.url}/${id}`,hotel);
}
public deleteHotelService(id:number):Observable<any>
{
  return this.http.delete(`${this.url}/${id}`);
}
}
