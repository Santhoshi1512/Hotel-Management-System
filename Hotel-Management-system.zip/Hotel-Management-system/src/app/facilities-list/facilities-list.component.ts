import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Facilities } from '../facilities';
import { FacilitiesService } from '../facilities.service';

@Component({
  selector: 'app-facilities-list',
  templateUrl: './facilities-list.component.html',
  styleUrls: ['./facilities-list.component.css']
})
export class FacilitiesListComponent implements OnInit {
facilities:Facilities[];
id:number;
placeId:number
  constructor(private facilityService:FacilitiesService,private router :Router,private activatedroute:ActivatedRoute) { }

  ngOnInit(): void {
   this.getfacilitiesList();
   this.placeId=this.activatedroute.snapshot.params["placeId"];

  }
  getfacilitiesList(){
this.id=this.activatedroute.snapshot.params["id"];
  this.facilityService.getFacilitiesListService(this.id).subscribe(
    data=>{this.facilities=data,
    console.log(data)}
)
    }
updateFacility(facilityId: number)
{
this.router.navigate(['/updatefacility',facilityId,this.id,this.placeId])
}
deleteFacility(facilityId:number)
{
this.facilityService.deleteFacilityService(facilityId).subscribe(
  data=>{console.log("Deleted succesfully"),
  this.getfacilitiesList();},
  error=>console.log("failed")
  )
}
logOut()
{
  this.router.navigate(['/welcomepage'])
}
back()
{
  this.router.navigate(['/hotellist',this.placeId])

}}
