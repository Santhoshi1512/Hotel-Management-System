import { Place } from './place';

describe('Place', () => {
  it('should create an instance', () => {
    expect(new Place()).toBeTruthy();
  });
});
