import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Hotel } from '../hotel';
import { HotelService } from '../hotel.service';

@Component({
  selector: 'app-create-hotel',
  templateUrl: './create-hotel.component.html',
  styleUrls: ['./create-hotel.component.css']
})
export class CreateHotelComponent implements OnInit {
hotel=new Hotel();
placeId:number
  constructor(private hotelService:HotelService,private router:Router,private activatedroute:ActivatedRoute) { }

  ngOnInit(): void {
  }
  saveHotel(){
    console.log(this.hotel)
    this.placeId=this.activatedroute.snapshot.params["placeId"];
    this.hotelService.createHotelService(this.hotel,this.placeId).subscribe( data =>{
      console.log(data);
      alert("added successfully")
      this.goToHotelList();
    },
    error => console.log(error));
  }

  goToHotelList(){
    this.router.navigate(['/hotellist',this.placeId]);
  }
  
  onSubmit(){
    console.log(this.hotel);
    this.saveHotel();
  }
  logOut()
{
  this.router.navigate(['/welcomepage'])
}
}
