import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { Location } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {
customers:Customer[]
  constructor(private customerService:CustomerService,private router:Router) { }

  ngOnInit(): void {
    this.customerService.getAllCustomersService().subscribe(
      data=>this.customers=data,
      error=>console.log(error)
    )
  }

logOut()
{
  this.router.navigate(['/welcomepage'])
}
}
