import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { Room } from '../room';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-create-room',
  templateUrl: './create-room.component.html',
  styleUrls: ['./create-room.component.css']
})
export class CreateRoomComponent implements OnInit {
room=new Room();
id:number;
placeId:number
  constructor(private rommService:RoomService,private router :Router,private activatedroute:ActivatedRoute) { }

  ngOnInit(): void {
    this.placeId=this.activatedroute.snapshot.params["placeId"];

  }
  saveRoom(){
    console.log(this.room)
    this.id=this.activatedroute.snapshot.params["id"];
    this.rommService.createRoomService(this.room,this.id).subscribe( data =>{
      console.log(data);
      alert("added successfully")
      this.goToRoomList();
    },
    error => console.log(error));
  }

  goToRoomList(){
    this.router.navigate(['/roomlist',this.id,this.placeId]);
  }
  
  onSubmit(){
    console.log(this.room);
    this.saveRoom();
  }
  logOut()
{
  this.router.navigate(['/welcomepage'])
}
  statuses=["true","false"]
}
