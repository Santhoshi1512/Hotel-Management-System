import { Customer } from './customer';

describe('Admin', () => {
  it('should create an instance', () => {
    expect(new Customer()).toBeTruthy();
  });
});
