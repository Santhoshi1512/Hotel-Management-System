import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Action } from 'rxjs/internal/scheduler/Action';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer-profile',
  templateUrl: './customer-profile.component.html',
  styleUrls: ['./customer-profile.component.css']
})
export class CustomerProfileComponent implements OnInit {
  customer:Customer=new Customer;
  customerId:number
  constructor(private customerService:CustomerService,private activatedRoute:ActivatedRoute,private route:Router) { }

  ngOnInit(): void {
    this.getCustomerDetails();
  }
  getCustomerDetails(){
    this.customerId=this.activatedRoute.snapshot.params["customerId"]
      this.customerService.getCustomerById(this.customerId).subscribe(
        data=>{this.customer=data,
        console.log(data)}
    )
        }
        saveProfile(customerId:number,customer:Customer)
        {
          this.customerService.saveProfileService(customerId,customer).subscribe(
            data=>{console.log(data),
            alert("Profile Updated Successfully");},
            error=>console.log(error)
          )
        }
        backToCustomerHomePlace(customerId:number)
        {
        this.route.navigate(['\customerhomeplace',customerId])
        }
        logOut()
        {
          this.route.navigate(['/welcomepage'])
        }
        home()
        {
          this.route.navigate(['/customerhomeplace',this.customerId])
        }
        customerProfile()
        {
          this.route.navigate(['/profile',this.customerId])
        }
        genders=["Male","Female","Other"]
        contactUs()
        {
          this.route.navigate(['/contact'])
        }
}
