import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
customer=new Customer();
status:boolean
customerId:number
message=""
  constructor(private customerService:CustomerService,private route:Router) { }

  ngOnInit(): void {
    
  }
submitEmail()
{
  this.customerService.getCustomerByEmail(this.customer).subscribe(
    data=>{console.log(data),
      alert("Success......enter new password")
    this.customerId=data.customerId,
this.customer=data
this.status=true},

    error=>{console.log(error),
      this.message="email does not exist! enter correct email."
      this.status=false}
  )
}
submitPass()
{
  this.customerService.saveProfileService(this.customerId,this.customer).subscribe(
    data=>{console.log(data),
    alert("Password Updated Successfully");
  this.route.navigate(['/customerlogin'])},
    error=>console.log(error)
  )
}
}
