import { StringMapWithRename } from "@angular/compiler/src/compiler_facade_interface";

export class Payement {
    payementId:number
    roomId:number
firstName:String;
lastName:String;
district:String;
state:String
zipCode:String
emailID:String
 totalPrice:number
 roomNumber:String;
 roomType:String;
 roomPrice:number;
checkIn:Date;
checkOut:Date;
nameOnCard:String;
cardNumber:String;
cvv:number;
expYear:String
hotelName:String;
hotelPlace:String
paidDate:String
}
