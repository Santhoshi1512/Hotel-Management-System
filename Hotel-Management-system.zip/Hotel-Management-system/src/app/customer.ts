export class Customer {
    customerId:number;
    firstName:String;
    lastName:String;
    dateOfBirth:Date;
    phoneNumber:String;
    district:String;
    state:String;
    zipCode:String;
    emailID:String;
    password:String;
    image:String
    gender:String
    
}


