import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Booking } from '../booking';
import { BookingService } from '../booking.service';
import { Customer } from '../customer';
import { Hotel } from '../hotel';
import { HotelService } from '../hotel.service';
import { Payement } from '../payement';
import { PayementService } from '../payement.service';
import { Room } from '../room';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-payement',
  templateUrl: './payement.component.html',
  styleUrls: ['./payement.component.css']
})
export class PayementComponent implements OnInit {

roomId:number
customerId:number
id:number
payementId:number
hotel=new Hotel();
payement=new Payement();
room=new Room();
customer=new Customer();
nights:number
roomPrice:number
booking=new Booking();

  constructor(private activatedRout:ActivatedRoute,private payementService:PayementService,private bookingService:BookingService,private hotelService:HotelService,private router:Router) { }
  date=new Date();
  currentYear=this.date.getUTCFullYear();
  currentMonth=this.date.getUTCMonth()+1;
  currentday=this.date.getUTCDate();
  FinalMonth:any;
  FinalDay:any;
 todayDate:String
  ngOnInit(): void {
    if(this.currentMonth<10)
    {
      this.FinalMonth="0"+this.currentMonth;
    
    }else{
      this.FinalMonth=this.currentMonth;
    }
   
    if(this.currentday<10)
    {
      this.FinalDay="0"+this.currentday;
    
    }else{
      this.FinalDay=this.currentday;
    }
this.todayDate=this.FinalMonth+"-"+this.FinalDay+"-"+this.currentYear;
console.log("System Date"+this.todayDate)
  this.payement.checkIn=this.activatedRout.snapshot.params["checkIn"]
  this.payement.checkOut=this.activatedRout.snapshot.params["checkOut"]

    this.roomId=this.activatedRout.snapshot.params["roomId"]
    this.customerId=this.activatedRout.snapshot.params["customerId"]
    this.id=this.activatedRout.snapshot.params["id"]


  this.getRoomDetails();
 
  this.getCustomerDetails();
  this.getHotelDetails();

 console.log("Date"+this.getDateDiff(this.payement.checkIn,this.payement.checkOut));
 this.nights=this.getDateDiff(this.payement.checkIn,this.payement.checkOut);
 console.log(this.nights)

 console.log("roomPrice"+this.room.roomPrice," nights "+this.nights)

 console.log(this.payement.totalPrice)
  }
  getDateDiff(sDate: Date,eDate: Date)
{
  var startDate=new Date(sDate);
  var endDate=new Date(eDate);
  var Time=endDate.getTime()-startDate.getTime();
  return Time / (1000*3600*24);
}
getHotelDetails()
{
  this.hotelService.getHotelByIdService(this.id).subscribe(
    data=>{console.log(data),
    this.hotel=data},
    error=>console.log(error)
  )
}
  getRoomDetails()
  {
    this.payementService.getRoomDetailsService(this.roomId).subscribe(
      data=>{console.log(data),
this.room=data,
console.log(this.room.roomPrice),
this.payement.totalPrice=(this.nights)*(this.room.roomPrice),
console.log("total price "+this.payement.totalPrice)},
      error=>console.log(error)
    )
  }
  getCustomerDetails()
  {
this.payementService.getCustomerDetailsService(this.customerId).subscribe(
  data=>{console.log(data),
  this.customer=data},
  error=>console.log(error)
)
  }
addToPayement(roomId:number,room:Room,checkIn:Date,checkOut:Date)
{
this.booking.checkIn=checkIn
this.booking.checkOut=checkOut
this.booking.bookedDate=this.todayDate
this.payement.paidDate=this.todayDate

  this.bookingService.bookRoomService(this.id,roomId,this.customerId,this.booking).subscribe(
    data=>console.log(data),
    error=>console.log(error)
  )
  this.payementService.addToPayementService(roomId,this.customerId,this.id,this.payement).subscribe(
    data=>{console.log("payement success"+data),
this.payementId=data.payementId,
    alert("Payement Successfull"),
    this.router.navigate(['/payementreciept',this.customerId,this.payementId])},
    error=>console.log(error)
  )
  
  console.log("Date"+this.getDateDiff(this.payement.checkIn,this.payement.checkOut));
 
}
back()
{
  this.router.navigate(['/viewroomlist',this.id,this.customerId])
}
home()
{
  this.router.navigate(['/customerhomeplace',this.customerId])
}
customerProfile()
{
  this.router.navigate(['profile',this.customerId])
}
logOut()
{
  this.router.navigate(['/welcomepage'])
}
contactUs()
    {
      this.router.navigate(['/contact'])
    }
}
