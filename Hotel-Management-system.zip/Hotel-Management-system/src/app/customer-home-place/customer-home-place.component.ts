import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Place } from '../place';
import { PlaceService } from '../place.service';

@Component({
  selector: 'app-customer-home-place',
  templateUrl: './customer-home-place.component.html',
  styleUrls: ['./customer-home-place.component.css']
})
export class CustomerHomePlaceComponent implements OnInit {
  places:Place[];
  customerId:number
  constructor(private placeService:PlaceService,private route:Router,private activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {
this.customerId=this.activatedRoute.snapshot.params["customerId"]
    this.getPlaceList();
  }
  private getPlaceList()
  {
    this.placeService.getPlaceListService().subscribe(data => {
      this.places = data;
    });}
    getHotelList(placeId:number)
    {
      this.route.navigate(['/customerhome',placeId,this.customerId])
    }
    
    customerProfile()
    {
      this.route.navigate(['/profile',this.customerId])
    }
    logOut()
    {
      this.route.navigate(['/welcomepage'])
    }
    back()
    {
      this.route.navigate(['/welcomepage'])
    }
    bookingDetails ()
    {
      this.route.navigate(['/viewbookinglist',this.customerId])
    }
    contactUs()
    {
      this.route.navigate(['/contact'])
    }

}
