import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerHomePlaceComponent } from './customer-home-place.component';

describe('CustomerHomePlaceComponent', () => {
  let component: CustomerHomePlaceComponent;
  let fixture: ComponentFixture<CustomerHomePlaceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerHomePlaceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerHomePlaceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
