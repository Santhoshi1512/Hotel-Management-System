import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { FormsModule } from '@angular/forms';
import { CustomerRegisterComponent } from './customer-register/customer-register.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { WelcomeComponent } from './welcome/welcome.component';

import { AdminLoginComponent } from './admin-login/admin-login.component';
import { CreateHotelComponent } from './create-hotel/create-hotel.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { HotelListComponent } from './hotel-list/hotel-list.component';
import { CreateRoomComponent } from './create-room/create-room.component';
import { UpdateHotelComponent } from './update-hotel/update-hotel.component';
import { RoomListComponent } from './room-list/room-list.component';
import { UpdateRoomComponent } from './update-room/update-room.component';
import { CreateFacilitiesComponent } from './create-facilities/create-facilities.component';
import { FacilitiesListComponent } from './facilities-list/facilities-list.component';
import { UpdateFacilitiesComponent } from './update-facilities/update-facilities.component';
import { ViewRoomListComponent } from './view-room-list/view-room-list.component';
import { ViewFacilityListComponent } from './view-facility-list/view-facility-list.component';
import { CustomerHomeComponent } from './customer-home/customer-home.component';
import { PayementComponent } from './payement/payement.component';
import { CustomerProfileComponent } from './customer-profile/customer-profile.component';
import { PayementListComponent } from './payement-list/payement-list.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { ReceiptComponent } from './receipt/receipt.component';
import { BookingListComponent } from './booking-list/booking-list.component';
import { ViewBookingListComponent } from './view-booking-list/view-booking-list.component';
import { AvailabilityComponent } from './availability/availability.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { CreatePlaceComponent } from './create-place/create-place.component';
import { PlaceListComponent } from './place-list/place-list.component';
import { UpdatePlaceComponent } from './update-place/update-place.component';
import { CustomerHomePlaceComponent } from './customer-home-place/customer-home-place.component';




@NgModule({
  declarations: [
    AppComponent,
    
    CustomerRegisterComponent,
         CustomerLoginComponent,
         WelcomeComponent,
      AdminLoginComponent,
       CreateHotelComponent,
       AdminHomeComponent,
       HotelListComponent,
       CreateRoomComponent,
       UpdateHotelComponent,
       RoomListComponent,
       UpdateRoomComponent,
       CreateFacilitiesComponent,
       FacilitiesListComponent,
       UpdateFacilitiesComponent,
       ViewRoomListComponent,
       ViewFacilityListComponent,
       CustomerHomeComponent,
       PayementComponent,
       CustomerProfileComponent,
       PayementListComponent,
       CustomerListComponent,
       ContactUsComponent,
       ReceiptComponent,
       BookingListComponent,
       ViewBookingListComponent,
       AvailabilityComponent,
       AboutUsComponent,
       ForgotPasswordComponent,
       CreatePlaceComponent,
       PlaceListComponent,
       UpdatePlaceComponent,
       CustomerHomePlaceComponent,
       
      

       
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule,
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
