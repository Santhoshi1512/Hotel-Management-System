import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Booking } from './booking';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  constructor(private http:HttpClient) { }
  private url="http://localhost:8080/api/bookings"
  public bookRoomService(id:number,roomId:number,customerId:number,booking:Booking):Observable<any>
{
return this.http.post<any>(`${this.url}/${id}/${roomId}/${customerId}`,booking);
}
public getAllBookingsByCustomerIdService(customerId:number):Observable<Booking[]>
{
  return this.http.get<Booking[]>(`${this.url}/${customerId}`);
}
public getAllBookingsService():Observable<Booking[]>
{
  return this.http.get<Booking[]>(`${this.url}`);
}
public deleteBookingService(bookingId:number):Observable<any>{
  return this.http.delete(`${this.url}/${bookingId}`);
}
public checkAvailabilityService(checkIn:Date,checkOut:Date,roomId:number):Observable<any>
 {
   return this.http.get<any>(`${this.url}/${checkIn}/${checkOut}/${roomId}`);
 }
 private url2="http://localhost:8080/api/bookings/rooms"

public getAllBookingsByRoomIdService(roomId:number):Observable<Booking[]>
{
  return this.http.get<Booking[]>(`${this.url2}/${roomId}`)
}
}
