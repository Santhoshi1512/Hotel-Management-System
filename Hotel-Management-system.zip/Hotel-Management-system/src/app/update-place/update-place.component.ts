import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HotelService } from '../hotel.service';
import { Place } from '../place';
import { PlaceService } from '../place.service';

@Component({
  selector: 'app-update-place',
  templateUrl: './update-place.component.html',
  styleUrls: ['./update-place.component.css']
})
export class UpdatePlaceComponent implements OnInit {

  placeId:number;
place:Place=new Place();
message=""
  constructor(private activatedroute:ActivatedRoute,private placeService:PlaceService,private route:Router)
   { }

  ngOnInit(): void {
this.placeId=this.activatedroute.snapshot.params["placeId"];
this.placeService.getPlaceByIdService(this.placeId).subscribe(
  data=>this.place=data,
 
  error=>console.log(error),
   
)
  }
  updatePlace()
  {
    this.placeService.updatePlaceService(this.placeId,this.place).subscribe(
      data=>{console.log(data),
        alert("updated successfully")
      this.route.navigate(['/placelist'])},
      error=>console.log("update failed")
    )
  }
  logOut()
  {
    this.route.navigate(['/welcomepage'])
  }

}
